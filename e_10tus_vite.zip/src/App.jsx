
import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

// ============================
// E_10tus — India Travel Explorer
// Creator: Puspendu Jana (Full ownership granted to you)
// ============================

// Sample dataset (editable)
const DESTINATIONS = [
  {
    id: "leh-ladakh",
    name: "Leh–Ladakh",
    state: "Ladakh",
    type: ["Trekking", "Adventure", "Road Trip"],
    bestSeason: "Jun–Sep",
    budget: 4,
    excerpt: "High-altitude deserts, monasteries, and iconic passes like Khardung La.",
    highlights: ["Pangong Tso", "Nubra Valley", "Magnetic Hill"],
    image: "https://images.unsplash.com/photo-1580492495261-5e3a6b3b2b4c?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "kerala-backwaters",
    name: "Kerala Backwaters",
    state: "Kerala",
    type: ["Boat Riding", "Relaxation", "Nature"],
    bestSeason: "Oct–Feb",
    budget: 3,
    excerpt: "Palm-fringed canals, houseboats, and serene villages.",
    highlights: ["Alleppey", "Kumarakom", "Vembanad Lake"],
    image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "goa-beaches",
    name: "Goa Beaches",
    state: "Goa",
    type: ["Beach", "Nightlife", "Water Sports"],
    bestSeason: "Nov–Feb",
    budget: 3,
    excerpt: "Golden sands, Portuguese heritage, and vibrant shacks.",
    highlights: ["Calangute", "Baga", "Palolem"],
    image: "https://images.unsplash.com/photo-1587474260584-136574528ed5?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "sikkim-treks",
    name: "Sikkim Treks",
    state: "Sikkim",
    type: ["Trekking", "Nature", "Himalayas"],
    bestSeason: "Apr–Jun",
    budget: 2,
    excerpt: "Emerald valleys, rhododendron forests, and views of Kanchenjunga.",
    highlights: ["Goechala", "Dzongri", "Yuksom"],
    image: "https://images.unsplash.com/photo-1617356587898-bdbf118f302f?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "varanasi-ghats",
    name: "Varanasi Ghats",
    state: "Uttar Pradesh",
    type: ["Spiritual", "Heritage", "Boat Riding"],
    bestSeason: "Oct–Mar",
    budget: 2,
    excerpt: "Ancient ghats, Ganga Aarti, and sunrise boat rides on the Ganges.",
    highlights: ["Dashashwamedh Ghat", "Assi Ghat", "Kashi Vishwanath"],
    image: "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "andaman-scuba",
    name: "Andaman Islands",
    state: "Andaman & Nicobar",
    type: ["Beach", "Water Sports", "Boat Riding"],
    bestSeason: "Nov–Apr",
    budget: 4,
    excerpt: "Turquoise waters, coral reefs, and powder-soft sand.",
    highlights: ["Havelock", "Radhanagar Beach", "Neil Island"],
    image: "https://images.unsplash.com/photo-1540541338287-41700207dee6?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "meghalaya-caves",
    name: "Meghalaya Caves & Falls",
    state: "Meghalaya",
    type: ["Nature", "Trekking", "Adventure"],
    bestSeason: "Oct–Apr",
    budget: 2,
    excerpt: "Living root bridges, misty hills, caves and roaring waterfalls.",
    highlights: ["Cherrapunji", "Mawsmai Cave", "Dawki"],
    image: "https://images.unsplash.com/photo-1603262110263-fb0112e7cc33?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "jaipur-heritage",
    name: "Jaipur Heritage",
    state: "Rajasthan",
    type: ["Heritage", "City", "Culture"],
    bestSeason: "Oct–Mar",
    budget: 3,
    excerpt: "Pink City palaces, forts, bazaars, and royal Rajasthani cuisine.",
    highlights: ["Amer Fort", "City Palace", "Hawa Mahal"],
    image: "https://images.unsplash.com/photo-1549893075-7c13ea9b58fa?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "kashmir-valley",
    name: "Kashmir Valley",
    state: "Jammu & Kashmir",
    type: ["Nature", "Boat Riding", "Snow"],
    bestSeason: "Apr–Oct",
    budget: 3,
    excerpt: "Shikara rides on Dal Lake, alpine meadows, and snowy peaks.",
    highlights: ["Srinagar", "Gulmarg", "Pahalgam"],
    image: "https://images.unsplash.com/photo-1605379399642-870262d3d051?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "hampi-ruins",
    name: "Hampi Ruins",
    state: "Karnataka",
    type: ["Heritage", "UNESCO", "Trekking"],
    bestSeason: "Nov–Feb",
    budget: 2,
    excerpt: "Boulder-strewn landscapes and Vijayanagara empire ruins.",
    highlights: ["Virupaksha", "Vittala Temple", "Hemakuta Hills"],
    image: "https://images.unsplash.com/photo-1600855280804-dee4dfe3d93a?q=80&w=1600&auto=format&fit=crop",
  },
];

const CATEGORIES = [
  "Travel",
  "Trekking",
  "Boat Riding",
  "Beach",
  "Heritage",
  "Adventure",
  "Nature",
  "Water Sports",
  "City",
  "Spiritual",
];

const STATES = Array.from(new Set(DESTINATIONS.map((d) => d.state))).sort();

function Badge({ children, onClick, active }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1 rounded-2xl border text-sm transition shadow-sm hover:shadow ${
        active
          ? "bg-black text-white border-black"
          : "bg-white text-gray-700 border-gray-300 hover:border-gray-400"
      }`}
    >
      {children}
    </button>
  );
}

function Card({ place, onOpen }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="bg-white rounded-2xl overflow-hidden shadow hover:shadow-lg transition flex flex-col"
    >
      <div className="h-44 w-full overflow-hidden">
        <img src={place.image} alt={place.name} className="h-full w-full object-cover" loading="lazy" />
      </div>
      <div className="p-4 flex-1 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">{place.name}</h3>
          <span title="Budget level" className="text-sm text-gray-500">
            {"₹".repeat(place.budget)}
          </span>
        </div>
        <div className="text-sm text-gray-600">{place.state} • {place.bestSeason}</div>
        <p className="text-sm text-gray-700 line-clamp-2">{place.excerpt}</p>
        <div className="flex items-center gap-2 flex-wrap mt-auto">
          {place.type.slice(0, 3).map((t) => (
            <span key={t} className="text-xs px-2 py-0.5 rounded-full bg-gray-100 border border-gray-200">
              {t}
            </span>
          ))}
        </div>
        <button onClick={() => onOpen(place)} className="mt-2 w-full rounded-xl bg-black text-white py-2 text-sm hover:bg-gray-900">
          View Details
        </button>
      </div>
    </motion.div>
  );
}

function Modal({ open, onClose, place }) {
  if (!open || !place) return null;
  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          onClick={(e) => e.stopPropagation()}
          initial={{ scale: 0.98, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.98, opacity: 0 }}
          className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl"
        >
          <div className="h-56 w-full overflow-hidden">
            <img src={place.image} alt={place.name} className="h-full w-full object-cover" />
          </div>
          <div className="p-6 flex flex-col gap-3">
            <h3 className="text-2xl font-semibold">{place.name}</h3>
            <div className="text-sm text-gray-600">{place.state} • Best season: {place.bestSeason}</div>
            <p className="text-gray-700">{place.excerpt}</p>
            <div className="mt-2 flex gap-2 flex-wrap">
              {place.highlights.map((h) => (
                <span key={h} className="text-xs px-2 py-1 rounded-full bg-gray-100 border border-gray-200">
                  {h}
                </span>
              ))}
            </div>
            <div className="flex items-center justify-end gap-3 mt-4">
              <button onClick={onClose} className="rounded-xl px-4 py-2 border border-gray-300 hover:bg-gray-50">Close</button>
              <a href={`https://www.google.com/search?q=${encodeURIComponent(place.name + " travel guide")}`} target="_blank" rel="noreferrer" className="rounded-xl px-4 py-2 bg-black text-white hover:bg-gray-900">Open Guide</a>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 bg-black text-white grid place-items-center rounded-2xl font-bold">E</div>
          <div>
            <div className="text-xl font-bold tracking-tight">E_10tus</div>
            <div className="text-[11px] uppercase tracking-wider text-gray-500 -mt-1">Explore India • By Puspendu Jana</div>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm text-gray-700">
          <a href="#explore" className="hover:text-black">Explore</a>
          <a href="#map" className="hover:text-black">Map</a>
          <a href="#about" className="hover:text-black">About</a>
        </nav>
        <a href="#about" className="rounded-xl bg-black text-white px-4 py-2 text-sm hover:bg-gray-900">Start Exploring</a>
      </div>
    </header>
  );
}

function Hero({ onScrollToExplore }) {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-blue-50" />
      <div className="max-w-7xl mx-auto px-4 py-16 md:py-24 relative">
        <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="text-4xl md:text-6xl font-extrabold tracking-tight">
          Explore India with <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">E_10tus</span>
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="mt-4 text-lg md:text-xl text-gray-700 max-w-3xl">
          Find the best places for travel, trekking, boat riding, beaches, heritage, and more — curated across every corner of India.
        </motion.p>
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="mt-8 flex items-center gap-3">
          <button onClick={onScrollToExplore} className="rounded-2xl bg-black text-white px-5 py-3 text-sm md:text-base hover:bg-gray-900 shadow">Explore Destinations</button>
          <a href="#map" className="rounded-2xl border px-5 py-3 text-sm md:text-base hover:bg-gray-50">View Map (beta)</a>
        </motion.div>
      </div>
    </section>
  );
}

function Filters({ search, setSearch, activeCats, toggleCat, state, setState, maxBudget, setMaxBudget }) {
  return (
    <div className="bg-white/70 backdrop-blur border border-gray-200 rounded-3xl p-4 md:p-5 shadow-sm">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <label className="text-xs uppercase text-gray-500">Search</label>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find places, states, or tags..." className="w-full mt-1 rounded-xl border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black" />
        </div>
        <div>
          <label className="text-xs uppercase text-gray-500">State</label>
          <select value={state} onChange={(e) => setState(e.target.value)} className="w-full mt-1 rounded-xl border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black">
            <option value="">All states</option>
            {STATES.map((s) => (<option key={s} value={s}>{s}</option>))}
          </select>
        </div>
        <div>
          <label className="text-xs uppercase text-gray-500">Max Budget</label>
          <input type="range" min={1} max={5} value={maxBudget} onChange={(e) => setMaxBudget(Number(e.target.value))} className="w-full mt-2" />
          <div className="text-xs text-gray-600 mt-1">Up to {"₹".repeat(maxBudget)}</div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (<Badge key={c} active={activeCats.includes(c)} onClick={() => toggleCat(c)}>{c}</Badge>))}
      </div>
    </div>
  );
}

export default function App() {
  const [search, setSearch] = useState("");
  const [activeCats, setActiveCats] = useState(["Travel"]);
  const [state, setState] = useState("");
  const [maxBudget, setMaxBudget] = useState(5);
  const [openPlace, setOpenPlace] = useState(null);

  const toggleCat = (c) => {
    setActiveCats((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return DESTINATIONS.filter((d) => {
      const matchesSearch =
        !q ||
        d.name.toLowerCase().includes(q) ||
        d.state.toLowerCase().includes(q) ||
        d.type.some((t) => t.toLowerCase().includes(q)) ||
        d.highlights.some((h) => h.toLowerCase().includes(q));
      const matchesState = !state || d.state === state;
      const matchesBudget = d.budget <= maxBudget;
      const matchesCats =
        activeCats.length === 0 ||
        activeCats.some((c) => c === "Travel" || d.type.includes(c));

      return matchesSearch && matchesState && matchesBudget && matchesCats;
    });
  }, [search, activeCats, state, maxBudget]);

  const scrollToExplore = () => {
    document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-white to-gray-50 text-gray-900">
      <Header />
      <Hero onScrollToExplore={scrollToExplore} />

      <main id="explore" className="max-w-7xl mx-auto px-4 py-10">
        <div className="flex items-end justify-between gap-4 mb-4">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">Explore Destinations</h2>
            <p className="text-gray-600 text-sm">Filter by category, state, and budget — click a card for details.</p>
          </div>
          <div className="text-xs text-gray-500">Results: {filtered.length}</div>
        </div>

        <Filters search={search} setSearch={setSearch} activeCats={activeCats} toggleCat={toggleCat} state={state} setState={setState} maxBudget={maxBudget} setMaxBudget={setMaxBudget} />

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filtered.map((place) => (<Card key={place.id} place={place} onOpen={setOpenPlace} />))}
          </AnimatePresence>
        </div>

        <section id="map" className="mt-16">
          <h3 className="text-xl font-semibold">Map (beta)</h3>
          <p className="text-gray-600 text-sm mb-3">A simplified placeholder map. Integrate Google Maps or Leaflet later.</p>
          <div className="rounded-3xl border border-dashed border-gray-300 p-6 grid md:grid-cols-3 gap-6 bg-white">
            <div className="md:col-span-2 rounded-2xl bg-gray-100 h-64 grid place-items-center text-gray-500">Interactive Map Coming Soon</div>
            <div className="flex flex-col gap-3">{DESTINATIONS.slice(0, 5).map((d) => (<div key={d.id} className="p-3 border rounded-2xl bg-white flex items-center gap-3"><img src={d.image} alt={d.name} className="h-12 w-12 rounded-xl object-cover" /><div className="text-sm"><div className="font-medium">{d.name}</div><div className="text-gray-600">{d.state}</div></div></div>))}</div>
          </div>
        </section>

        <section id="about" className="mt-16">
          <div className="rounded-3xl bg-black text-white p-8 md:p-12 grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold">About E_10tus</h3>
              <p className="mt-3 text-gray-100">E_10tus is a clean, modern explorer to discover places across India for travel, trekking, boat riding, beaches, heritage, and beyond. Built with love for wanderers and makers.</p>
            </div>
            <div>
              <div className="bg-white/10 rounded-2xl p-4">
                <dl className="grid grid-cols-2 gap-4 text-sm">
                  <div><dt className="text-gray-300">Creator</dt><dd className="font-semibold">Puspendu Jana</dd></div>
                  <div><dt className="text-gray-300">Ownership</dt><dd className="font-semibold">You have full rights</dd></div>
                  <div><dt className="text-gray-300">Tech</dt><dd className="font-semibold">React + Tailwind + Framer Motion</dd></div>
                  <div><dt className="text-gray-300">Data</dt><dd className="font-semibold">Editable JSON inside code</dd></div>
                </dl>
              </div>
              <p className="mt-3 text-gray-200 text-sm">Want admin features (Auth, CMS, Maps, Itineraries, Exports)? You can extend this easily.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="mt-16 border-t">
        <div className="max-w-7xl mx-auto px-4 py-8 text-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <div className="font-semibold">E_10tus</div>
            <div className="text-gray-600">© {new Date().getFullYear()} Puspendu Jana. All rights reserved. You own full authorization to use, modify, and publish this website.</div>
          </div>
          <div className="text-gray-600">Made in India • <a className="underline" href="#about">Creator: Puspendu Jana</a></div>
        </div>
      </footer>

      <Modal open={!!openPlace} onClose={() => setOpenPlace(null)} place={openPlace} />
    </div>
  );
}
