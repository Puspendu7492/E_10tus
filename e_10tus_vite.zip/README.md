# E_10tus — Explore India
Creator: Puspendu Jana

## Quick start

1. Unzip the project.
2. Install dependencies:
   ```
   npm install
   ```
3. Run the dev server:
   ```
   npm run dev
   ```
4. Visit http://localhost:5173

## Deployment
You can deploy to Netlify/Vercel/GitHub Pages. Build with `npm run build`.

## Ownership
© 2025 Puspendu Jana — Creator. Full ownership/authorization granted.
